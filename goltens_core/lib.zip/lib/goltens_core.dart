library goltens_core;

///
/// In Some Services
/// =================
///
/// Use localFilePath for Android/iOS Mobile Platforms
///
/// Use byteArray and filename For Web Platforms
///
///