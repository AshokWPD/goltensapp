final String apiUrlOneSingnal = 'https://onesignal.com/api/v1/notifications';
final String oneSignalAppId = '7ea4ff4f-c154-4fd2-8cf6-d8ca1103f390';
final String oneSignalApiKey = 'NjFiZjJkYWQtNWM2Ny00OTc3LTk0NWYtY2FhNTIxODZmYzMx';